const quizData = [

    {

        question: "বাংলাদেশের রাজধানীর নাম কি?",

        options: ["ঢাকা", "চট্টগ্রাম", "খুলনা", "রাজশাহী"],

        answer: "ঢাকা",

        time: 15 // সেকেন্ড

    },

    {

        question: "বাংলাদেশের জাতীয় পশুর নাম কি?",

        options: ["রয়েল বেঙ্গল টাইগার", "হাতি", "হরিণ", "সিংহ"],

        answer: "রয়েল বেঙ্গল টাইগার",

        time: 15

    },

    {

        question: "বাংলাদেশের জাতীয় ফুলের নাম কি?",

        options: ["গোলাপ", "শাপলা", "জবা", "রজনীগন্ধা"],

        answer: "শাপলা",

        time: 10

    },

    {

        question: "বাংলাদেশের জাতীয় ফলের নাম কি?",

        options: ["আম", "লিচু", "কাঁঠাল", "পেয়ারা"],

        answer: "কাঁঠাল",

        time: 10

    },

    {

        question: "বাংলাদেশের জাতীয় পাখির নাম কি?",

        options: ["দোয়েল", "ময়না", "টিয়া", "শালিক"],

        answer: "দোয়েল",

        time: 10

    },

    {

        question: "বাংলাদেশের জাতীয় মাছের নাম কি?",

        options: ["রুই", "কাতল", "ইলিশ", "চিংড়ি"],

        answer: "ইলিশ",

        time: 10

    },

    {

        question: "বাংলাদেশের জাতীয় খেলা কি?",

        options: ["ক্রিকেট", "ফুটবল", "কাবাডি", "ব্যাডমিন্টন"],

        answer: "কাবাডি",

        time: 15

    },

    {

        question: "বাংলাদেশের জাতীয় মসজিদের নাম কি?",

        options: ["তারা মসজিদ", "ষাট গম্বুজ মসজিদ", "বায়তুল মোকাররম", "আতিয়া মসজিদ"],

        answer: "বায়তুল মোকাররম",

        time: 15

    },

    {

        question: "বাংলাদেশের জাতীয় কবির নাম কি?",

        options: ["রবীন্দ্রনাথ ঠাকুর", "কাজী নজরুল ইসলাম", "জসীম উদ্দীন", "জীবনানন্দ দাশ"],

        answer: "কাজী নজরুল ইসলাম",

        time: 15

    },

    {

        question: "বাংলাদেশের জাতীয় পতাকার ডিজাইনার কে?",

        options: ["শিল্পাচার্য জয়নুল আবেদিন", "কামরুল হাসান", "হামিদুর রহমান", "এস এম সুলতান"],

        answer: "কামরুল হাসান",

        time: 20

    },

    {

        question: "বাংলাদেশের জাতীয় স্মৃতিসৌধ কোথায় অবস্থিত?",

        options: ["ঢাকা", "সাভার", "গাজীপুর", "নারায়ণগঞ্জ"],

        answer: "সাভার",

        time: 15

    },

    {

        question: "বাংলাদেশের জাতীয় স্মৃতিসৌধের স্থপতি কে?",

        options: ["সৈয়দ মাইনুল হোসেন", "ফজলুর রহমান খান", "লুই কান", "হামিদুজ্জামান খান"],

        answer: "সৈয়দ মাইনুল হোসেন",

        time: 20

    },

    {

        question: "বাংলাদেশের সর্বোচ্চ শৃঙ্গের নাম কি?",

        options: ["কেওক্রাডং", "তাজিনডং (বিজয়)", "সাকা হাফং", "মৌদক মুয়াল"],

        answer: "সাকা হাফং", // (বিঃদ্রঃ এটি নিয়ে মতভেদ আছে, তবে সাকা হাফং বর্তমানে বেশি স্বীকৃত)

        time: 20

    },

    {

        question: "বাংলাদেশের দীর্ঘতম নদীর নাম কি?",

        options: ["পদ্মা", "মেঘনা", "যমুনা", "ব্রহ্মপুত্র"],

        answer: "মেঘনা", // সুরমা-মেঘনা প্রবাহ হিসেবে

        time: 15

    },

    {

        question: "বাংলাদেশের বৃহত্তম দ্বীপ কোনটি?",

        options: ["সেন্টমার্টিন", "হাতিয়া", "ভোলা", "সন্দ্বীপ"],

        answer: "ভোলা",

        time: 15

    },

    {

        question: "বাংলাদেশের একমাত্র প্রবাল দ্বীপ কোনটি?",

        options: ["কুতুবদিয়া", "মহেশখালী", "নিঝুম দ্বীপ", "সেন্টমার্টিন"],

        answer: "সেন্টমার্টিন",

        time: 15

    },

    {

        question: "বাংলাদেশের মুক্তিযুদ্ধ কত মাস স্থায়ী হয়েছিল?",

        options: ["৭ মাস", "৮ মাস", "৯ মাস", "১০ মাস"],

        answer: "৯ মাস",

        time: 10

    },

    {

        question: "বাংলাদেশের স্বাধীনতা দিবস কবে?",

        options: ["১৬ ডিসেম্বর", "২৬ মার্চ", "২১ ফেব্রুয়ারি", "১৪ এপ্রিল"],

        answer: "২৬ মার্চ",

        time: 10

    },

    {

        question: "বাংলাদেশের বিজয় দিবস কবে?",

        options: ["২৬ মার্চ", "১৪ ডিসেম্বর", "১৬ ডিসেম্বর", "২১ ফেব্রুয়ারি"],

        answer: "১৬ ডিসেম্বর",

        time: 10

    },

    {

        question: "শহীদ বুদ্ধিজীবী দিবস কবে?",

        options: ["২১ ফেব্রুয়ারি", "২৬ মার্চ", "১৪ ডিসেম্বর", "১৬ ডিসেম্বর"],

        answer: "১৪ ডিসেম্বর",

        time: 10

    },

    {

        question: "আন্তর্জাতিক মাতৃভাষা দিবস কোনটি?",

        options: ["২১ ফেব্রুয়ারি", "৮ মার্চ", "১ মে", "২৬ মার্চ"],

        answer: "২১ ফেব্রুয়ারি",

        time: 10

    },

    {

        question: "বাংলাদেশের প্রথম রাষ্ট্রপতি কে ছিলেন?",

        options: ["তাজউদ্দীন আহমদ", "সৈয়দ নজরুল ইসলাম", "শেখ মুজিবুর রহমান", "ক্যাপ্টেন এম মনসুর আলী"],

        answer: "শেখ মুজিবুর রহমান",

        time: 15

    },

    {

        question: "বাংলাদেশের প্রথম প্রধানমন্ত্রী কে ছিলেন?",

        options: ["শেখ মুজিবুর রহমান", "তাজউদ্দীন আহমদ", "এ. এইচ. এম. কামারুজ্জামান", "সৈয়দ নজরুল ইসলাম"],

        answer: "তাজউদ্দীন আহমদ",

        time: 15

    },

    {

        question: "বাংলাদেশের আইনসভার নাম কি?",

        options: ["গণপরিষদ", "জাতীয় সংসদ", "লোকসভা", "সিনেট"],

        answer: "জাতীয় সংসদ",

        time: 15

    },

    {

        question: "জাতীয় সংসদের আসন সংখ্যা কত?",

        options: ["৩০০", "৩৩০", "৩৫০", "৩৭০"],

        answer: "৩৫০", // (৩০০ সরাসরি + ৫০ সংরক্ষিত মহিলা আসন)

        time: 15

    },

    {

        question: "বাংলাদেশের রাষ্ট্রীয় ভাষার নাম কি?",

        options: ["ইংরেজি", "বাংলা", "হিন্দি", "উর্দু"],

        answer: "বাংলা",

        time: 10

    },

    {

        question: "বাংলাদেশের প্রধান সমুদ্র বন্দর কোনটি?",

        options: ["মোংলা", "পায়রা", "চট্টগ্রাম", "কক্সবাজার"],

        answer: "চট্টগ্রাম",

        time: 15

    },

    {

        question: "বাংলাদেশের বৃহত্তম স্থলবন্দর কোনটি?",

        options: ["হিলি", "সোনামসজিদ", "বাংলাবান্ধা", "বেনাপোল"],

        answer: "বেনাপোল",

        time: 15

    },

    {

        question: "বাংলাদেশের চলচিত্রের জনক কে?",

        options: ["জহির রায়হান", "আলমগীর কবির", "আবদুল জব্বার খান", "সুভাষ দত্ত"],

        answer: "আবদুল জব্বার খান",

        time: 20

    },

    {

        question: "বাংলাদেশের প্রথম এভারেস্ট বিজয়ী কে?",

        options: ["ওয়াসফিয়া নাজরীন", "এম এ মুহিত", "মুসা ইব্রাহীম", "নিশাত মজুমদার"],

        answer: "মুসা ইব্রাহীম",

        time: 15

    },

    {

        question: "বাংলাদেশের প্রথম নারী এভারেস্ট বিজয়ী কে?",

        options: ["ওয়াসফিয়া নাজরীন", "এম এ মুহিত", "নিশাত মজুমদার", "সেবিকা চাকমা"],

        answer: "নিশাত মজুমদার",

        time: 15

    },

    {

        question: "বাংলাদেশের জাতীয় শিশু দিবস কবে?",

        options: ["১৭ মার্চ", "২০ নভেম্বর", "১ জুন", "১৪ নভেম্বর"],

        answer: "১৭ মার্চ",

        time: 15

    },

    {

        question: "বাংলাদেশের জাতীয় উদ্যানের নাম কি (প্রধান)?",

        options: ["ভাওয়াল জাতীয় উদ্যান", "মধুপুর জাতীয় উদ্যান", "লাউয়াছড়া জাতীয় উদ্যান", "কাপ্তাই জাতীয় উদ্যান"],

        answer: "ভাওয়াল জাতীয় উদ্যান",

        time: 20

    },

    {

        question: "বাংলাদেশের 'সুন্দরবন' কি জন্য বিখ্যাত?",

        options: ["চা বাগান", "ঐতিহাসিক স্থান", "ম্যানগ্রোভ বন ও রয়েল বেঙ্গল টাইগার", "পাহাড়"],

        answer: "ম্যানগ্রোভ বন ও রয়েল বেঙ্গল টাইগার",

        time: 15

    },

    {

        question: "বাংলাদেশের কোন বিভাগে জেলার সংখ্যা সবচেয়ে বেশি?",

        options: ["ঢাকা", "চট্টগ্রাম", "রাজশাহী", "খুলনা"],

        answer: "ঢাকা",

        time: 15

    },

    {

        question: "বাংলাদেশের কোন বিভাগে জেলার সংখ্যা সবচেয়ে কম?",

        options: ["সিলেট", "বরিশাল", "রংপুর", "ময়মনসিংহ"],

        answer: "ময়মনসিংহ",

        time: 15

    },

    {

        question: "'ষাট গম্বুজ মসজিদ' কোথায় অবস্থিত?",

        options: ["ঢাকা", "রাজশাহী", "খুলনা", "বাগেরহাট"],

        answer: "বাগেরহাট",

        time: 15

    },

    {

        question: "লালবাগ কেল্লা কে নির্মাণ শুরু করেন?",

        options: ["শায়েস্তা খান", "ইসলাম খান", "যুবরাজ মুহাম্মদ আজম শাহ", "মীর জুমলা"],

        answer: "যুবরাজ মুহাম্মদ আজম শাহ",

        time: 20

    },

    {

        question: "পাহাড়পুর বৌদ্ধবিহার किस নামেও পরিচিত?",

        options: ["সোমপুর বিহার", "আনন্দ বিহার", "শালবন বিহার", "বিক্রমপুর বিহার"],

        answer: "সোমপুর বিহার",

        time: 15

    },

    {

        question: "বাংলাদেশের কোথায় চা বাগান বেশি দেখা যায়?",

        options: ["রাজশাহী", "খুলনা", "সিলেট", "বরিশাল"],

        answer: "সিলেট",

        time: 15

    },

    {

        question: "বাংলাদেশের 'সাতছড়ি জাতীয় উদ্যান' কোন জেলায় অবস্থিত?",

        options: ["মৌলভীবাজার", "হবিগঞ্জ", "সিলেট", "সুনামগঞ্জ"],

        answer: "হবিগঞ্জ",

        time: 20

    },

    {

        question: "বাংলাদেশের 'বঙ্গবন্ধু সেতু' কোন নদীর উপর নির্মিত?",

        options: ["পদ্মা", "মেঘনা", "যমুনা", "কর্ণফুলী"],

        answer: "যমুনা",

        time: 15

    },

    {

        question: "বাংলাদেশের 'পদ্মা সেতু'র দৈর্ঘ্য কত?",

        options: ["৫.৮০ কিমি", "৬.১৫ কিমি", "৬.৫০ কিমি", "৭.০০ কিমি"],

        answer: "৬.১৫ কিমি",

        time: 15

    },

    {

        question: "মুক্তিযুদ্ধ জাদুঘর কোথায় অবস্থিত?",

        options: ["শাহবাগ, ঢাকা", "আগারগাঁও, ঢাকা", "ধানমন্ডি, ঢাকা", "মিরপুর, ঢাকা"],

        answer: "আগারগাঁও, ঢাকা",

        time: 15

    },

    {

        question: "বাংলাদেশের সংবিধান কত সালে প্রণীত হয়?",

        options: ["১৯৭১", "১৯৭২", "১৯৭৩", "১৯৭৫"],

        answer: "১৯৭২",

        time: 15

    },

    {

        question: "বাংলাদেশের সংবিধানের মূলনীতি কয়টি?",

        options: ["২টি", "৩টি", "৪টি", "৫টি"],

        answer: "৪টি", // (জাতীয়তাবাদ, সমাজতন্ত্র, গণতন্ত্র ও ধর্মনিরপেক্ষতা)

        time: 15

    },

    {

        question: "বাংলাদেশের কোন বিজ্ঞানী পাটের জীবনরহস্য উন্মোচন করেন?",

        options: ["ড. কুদরত-এ-খুদা", "ড. মাকসুদুল আলম", "ড. জামাল নজরুল ইসলাম", "ড. মুহম্মদ জাফর ইকবাল"],

        answer: "ড. মাকসুদুল আলম",

        time: 20

    },

    {

        question: "'অসমাপ্ত আত্মজীবনী' গ্রন্থটির লেখক কে?",

        options: ["কাজী নজরুল ইসলাম", "রবীন্দ্রনাথ ঠাকুর", "শেখ মুজিবুর রহমান", "আহমদ ছফা"],

        answer: "শেখ মুজিবুর রহমান",

        time: 15

    },

    {

        question: "বাংলাদেশের আবহাওয়া অধিদপ্তর কোন মন্ত্রণালয়ের অধীন?",

        options: ["পরিবেশ, বন ও জলবায়ু পরিবর্তন মন্ত্রণালয়", "প্রতিরক্ষা মন্ত্রণালয়", "কৃষি মন্ত্রণালয়", "দুর্যোগ ব্যবস্থাপনা ও ত্রাণ মন্ত্রণালয়"],

        answer: "প্রতিরক্ষা মন্ত্রণালয়",

        time: 20

    },

    {

        question: "বাংলাদেশের শীতলতম মাস কোনটি?",

        options: ["ডিসেম্বর", "জানুয়ারি", "ফেব্রুয়ারি", "নভেম্বর"],

        answer: "জানুয়ারি",

        time: 15

    }

];

const quiz = document.getElementById('quiz');

const questionEl = document.getElementById('question');

const answerEls = document.querySelectorAll('.answer');

const a_text = document.getElementById('a_text');

const b_text = document.getElementById('b_text');

const c_text = document.getElementById('c_text');

const d_text = document.getElementById('d_text');

const submitBtn = document.getElementById('submit');

const timerSecEl = document.getElementById('timer-sec');

const progressBar = document.getElementById('progress-bar');

const resultContainer = document.getElementById('result-container');

const scoreTextEl = document.getElementById('score-text');

const restartBtn = document.getElementById('restart');

let currentQuiz = 0;

let score = 0;

let timer;

let timeLeft = 0;

loadQuiz();

function loadQuiz() {

    deselectAnswers();

    resultContainer.style.display = 'none'; // Ensure result is hidden when loading new quiz

    quiz.style.display = 'block'; // Ensure quiz is visible

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;

    a_text.innerText = currentQuizData.options[0];

    b_text.innerText = currentQuizData.options[1];

    c_text.innerText = currentQuizData.options[2];

    d_text.innerText = currentQuizData.options[3];

    // Reset button text and enable it

    submitBtn.innerText = "পরবর্তী প্রশ্ন";

    submitBtn.disabled = true; // Disable until an answer is selected or time runs out

    // Enable radio buttons

    answerEls.forEach(answerEl => answerEl.disabled = false);

    

    // Clear any previous correct/incorrect styling from list items

    document.querySelectorAll('.quiz-header ul li').forEach(li => {

        li.classList.remove('correct', 'incorrect');

    });

    timeLeft = currentQuizData.time;

    timerSecEl.innerText = timeLeft < 10 ? '0' + timeLeft : timeLeft;

    startTimer();

    updateProgressBar();

}

function startTimer() {

    clearInterval(timer); // Clear any existing timer

    timer = setInterval(() => {

        timeLeft--;

        timerSecEl.innerText = timeLeft < 10 ? '0' + timeLeft : timeLeft;

        if (timeLeft <= 0) {

            clearInterval(timer);

            handleTimeout();

        }

    }, 1000);

}

function handleTimeout() {

    // Mark as incorrect, show correct answer, and enable next button

    showCorrectAnswer(null); // Pass null as no answer was selected

    submitBtn.disabled = false;

    answerEls.forEach(answerEl => answerEl.disabled = true); // Disable options after timeout

    if (currentQuiz === quizData.length - 1) {

        submitBtn.innerText = "ফলাফল দেখুন";

    }

}

function deselectAnswers() {

    answerEls.forEach(answerEl => answerEl.checked = false);

}

function getSelected() {

    let answer;

    answerEls.forEach(answerEl => {

        if (answerEl.checked) {

            answer = answerEl.id;

        }

    });

    return answer;

}

function showCorrectAnswer(selectedAnswerValue) {

    const correctAnswer = quizData[currentQuiz].answer;

    const correctAnswerId = quizData[currentQuiz].options.findIndex(opt => opt === correctAnswer);

    const correctOptionElId = ['a', 'b', 'c', 'd'][correctAnswerId];

    document.getElementById(correctOptionElId).parentElement.classList.add('correct');

    if (selectedAnswerValue && selectedAnswerValue !== correctAnswer) {

        const selectedRadio = Array.from(answerEls).find(el => el.labels[0].innerText === selectedAnswerValue);

        if (selectedRadio) {

            selectedRadio.parentElement.classList.add('incorrect');

        }

    }

}

answerEls.forEach(answerEl => {

    answerEl.addEventListener('change', () => {

        if (getSelected()) {

            submitBtn.disabled = false;

            clearInterval(timer); // Stop timer on selection

            // Disable all options after one is selected

            answerEls.forEach(el => el.disabled = true);

            

            const selectedRadio = document.getElementById(getSelected());

            const selectedLabelText = selectedRadio.labels[0].innerText;

            const correctAnswer = quizData[currentQuiz].answer;

            if (selectedLabelText === correctAnswer) {

                score++;

                selectedRadio.parentElement.classList.add('correct');

            } else {

                selectedRadio.parentElement.classList.add('incorrect');

                showCorrectAnswer(selectedLabelText); // Show the correct one as well

            }

            if (currentQuiz === quizData.length - 1) {

                submitBtn.innerText = "ফলাফল দেখুন";

            }

        }

    });

});

submitBtn.addEventListener('click', () => {

    const selectedAnswer = getSelected();

    const currentQuizData = quizData[currentQuiz];

    // If submit is clicked after timeout or selection

    if (!selectedAnswer && timeLeft > 0) { // This case should ideally not happen if button is disabled

        // but as a fallback

        clearInterval(timer); 

        showCorrectAnswer(null);

    } else if (!selectedAnswer && timeLeft <= 0) {

        // Timeout already handled showing correct answer

    }

    // If an answer was selected, it's already processed by the 'change' event listener.

    currentQuiz++;

    updateProgressBar();

    if (currentQuiz < quizData.length) {

        loadQuiz();

    } else {

        showResults();

    }

});

function showResults() {

    clearInterval(timer);

    quiz.style.display = 'none'; // Hide the quiz part

    resultContainer.style.display = 'block';

    scoreTextEl.innerText = `আপনি ${quizData.length} টি প্রশ্নের মধ্যে ${score} টি সঠিক উত্তর দিয়েছেন।`;

    // You can add more detailed results or messages here

}

restartBtn.addEventListener('click', () => {

    currentQuiz = 0;

    score = 0;

    loadQuiz(); // This will also hide result and show quiz

});

function updateProgressBar() {

    const progressPercentage = (currentQuiz / quizData.length) * 100;

    progressBar.style.width = `${progressPercentage}%`;

}

// Initial progress bar update

updateProgressBar();